import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';

//main screen for map
class MyAppScreen extends StatefulWidget {
  @override
  State<MyAppScreen> createState() => _MyAppScreenState();
}

class _MyAppScreenState extends State<MyAppScreen> {
  late GoogleMapController mapController;
  // from administrative block
  double _originLatitude = 7.73400, _originLongitude = 4.42489;
  // to central mosque
  double _destLatitude = 7.72768, _destLongitude = 4.42290;
  Map<MarkerId, Marker> markers = {};
  Map<PolylineId, Polyline> polylines = {};
  List<LatLng> polylineCoordinates = [];
  PolylinePoints polylinePoints = PolylinePoints();
  String googleAPiKey = "AIzaSyBPGgOAJSzndiTz42G4hFL8E_NsqT3iKqQ";

  @override
  void initState() {
    super.initState();

    //origin marker
    _addMarker(LatLng(_originLatitude, _originLongitude), "origin",
        BitmapDescriptor.defaultMarker);

    //destination marker
    _addMarker(LatLng(_destLatitude, _destLongitude), "destination",
        BitmapDescriptor.defaultMarkerWithHue(90));
    _getPolyline();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blue,
          title: const Text('FPE city'),
        ),
        body: GoogleMap(
          initialCameraPosition: CameraPosition(
              target: LatLng(_originLatitude, _originLongitude), zoom: 15),
          myLocationEnabled: true,
          tiltGesturesEnabled: true,
          compassEnabled: true,
          scrollGesturesEnabled: true,
          zoomGesturesEnabled: true,
          onMapCreated: _onMapCreated,
          markers: Set<Marker>.of(markers.values),
        ),
        // ),

        //drawer start from here
        drawer: Drawer(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: const <Widget>[
              SizedBox(width: 0.0, height: 90.0),
              CircleAvatar(
                radius: 50.0,
                backgroundImage: AssetImage('assets/splash2.png'),
              ),
              SizedBox(width: 0.0, height: 25.0),
              Text(
                'DESIGNED BY:',
                style: TextStyle(
                  color: Colors.deepPurple,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(width: 0.0, height: 25.0),
              Text('FAJUMI MICHEAL:',
                  style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.5,
                  )),
              SizedBox(
                height: 15.0,
                child: Divider(
                  color: Colors.blue,
                  thickness: 3.0,
                  indent: 80.0,
                  endIndent: 80.0,
                ),
              ),
              Text(
                'CS20200202265',
                style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.5),
              ),
              SizedBox(width: 0.0, height: 25.0),
              Text('OLUWAYEMI BOLUWATIFE:',
                  style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.5,
                  )),
              SizedBox(
                height: 15.0,
                child: Divider(
                  color: Colors.blue,
                  thickness: 3.0,
                  indent: 80.0,
                  endIndent: 80.0,
                ),
              ),
              Text(
                'CS20200201419',
                style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.5),
              ),
              SizedBox(width: 0.0, height: 25.0),
              Text('OYEWO RIDWAN A.:',
                  style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.5,
                  )),
              SizedBox(
                height: 15.0,
                child: Divider(
                  color: Colors.blue,
                  thickness: 3.0,
                  indent: 80.0,
                  endIndent: 80.0,
                ),
              ),
              Text(
                'CS20200200571',
                style: TextStyle(
                    fontSize: 20.0,
                    color: Colors.red,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2.5),
              ),
              SizedBox(width: 0.0, height: 30.0),
              Text(
                'SUPERVISED BY:',
                style: TextStyle(
                  color: Colors.deepPurple,
                  fontWeight: FontWeight.bold,
                  fontSize: 20.0,
                ),
              ),
              Text(
                'Mr. ETUDAIYE A.I',
                style: TextStyle(
                  color: Colors.red,
                  letterSpacing: 2.5,
                  fontWeight: FontWeight.bold,
                  fontSize: 20.0,
                ),
              ),
              //SizedBox(height: 12.0,),
              //  ElevatedButton(
              //      style: ButtonStyle(
              //        backgroundColor: MaterialStateProperty.all<Color>(
              //            (Colors.purple),
              //        ),
              //      ),
              //       onPressed: (){
              //         Navigator.push(context, Availablecmd());
              //       },
              //       child: Text('View Available Command')
              //   ),
            ])));
  }

  void _onMapCreated(GoogleMapController controller) async {
    mapController = controller;
  }

  _addMarker(LatLng position, String id, BitmapDescriptor descriptor) {
    MarkerId markerId = MarkerId(id);
    Marker marker =
        Marker(markerId: markerId, icon: descriptor, position: position);
    markers[markerId] = marker;
  }

  _addPolyLine() {
    PolylineId id = PolylineId("poly");
    Polyline polyline = Polyline(
        polylineId: id, color: Colors.red, points: polylineCoordinates);
    polylines[id] = polyline;
    setState(() {});
  }

  _getPolyline() async {
    PolylineResult result = await polylinePoints.getRouteBetweenCoordinates(
        googleAPiKey,
        PointLatLng(_originLatitude, _originLongitude),
        PointLatLng(_destLatitude, _destLongitude),
        travelMode: TravelMode.walking,
        wayPoints: [PolylineWayPoint(location: "The federal polytechnic ede")]);
    if (result.points.isEmpty) {
      result.points.forEach((PointLatLng point) {
        polylineCoordinates.add(LatLng(point.latitude, point.longitude));
      });
    }
    _addPolyLine();
  }
}
