import 'package:flutter/material.dart';
// ignore: import_of_legacy_library_into_null_safe
import 'package:splashscreen/splashscreen.dart';
import 'home.dart';

//root method main()
void main() => runApp(const MyApp());

//root class for the app
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SplashHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

//splash screen page
class SplashHomePage extends StatefulWidget {
  @override
  State<SplashHomePage> createState() => _SplashHomePageState();
}

class _SplashHomePageState extends State<SplashHomePage> {
  @override
  Widget build(BuildContext context) {
    return SplashScreen(
      seconds: 5,
      navigateAfterSeconds: MyAppScreen(),
      backgroundColor: Colors.white,
      loaderColor: Colors.blue,
      title: const Text(
        'welcome to fpe smart city app',
        style: TextStyle(
          color: Colors.blue,
          fontWeight: FontWeight.bold,
          fontSize: 15.0,
          letterSpacing: 2.0,
        ),
      ),
      image: Image.asset('assets/splash2.png'),
      loadingText: const Text(
        'loading ...',
        style: TextStyle(
          color: Colors.blue,
        ),
      ),
      photoSize: 200.0,
    );
  }
}
