package com.example.fpe_city

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
