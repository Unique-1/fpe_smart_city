package installed

	google_maps_flutter 2.2.4
	flutter_polyline_points 1.0.0
	splashscreen 1.3.5
	

run code this to execute the application

flutter run --no-sound-null-safety